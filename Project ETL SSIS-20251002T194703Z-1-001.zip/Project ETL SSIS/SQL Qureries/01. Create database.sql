create database SSIS_Telecom_DB


